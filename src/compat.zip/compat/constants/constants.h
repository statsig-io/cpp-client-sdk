﻿#pragma once

namespace statsig_compatibility::constants {

// Statsig Metadata
const char *kSdkType = "cpp-client";

}